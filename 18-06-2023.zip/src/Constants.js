const Constants = {
    BASE_URL : 'http://localhost:8000/api'
}

export default Constants;